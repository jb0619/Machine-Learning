

 ****題目:Neural Network


使用Neural Network方式去辨識三種不同的水果

 ****模組套件

        NumPy
	OpenCV
	scikit-learn
	Matplotlib
 
 ****如何執行

可以使用jupyter-notebook打開"HW2.ipynb"且按下Run去執行程式碼。

